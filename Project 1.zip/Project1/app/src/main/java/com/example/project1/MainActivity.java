package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private boolean isImie = false;
    private boolean isNazwisko = false;
    private boolean isOcena = false;
    EditText ImiePoleTekstowe;
    EditText NazwiskoPoleTekstowe;
    EditText LiczbaOcenPoleTekstowe;
    Button przycisk;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         ImiePoleTekstowe=findViewById(R.id.imieEditText);
         NazwiskoPoleTekstowe=findViewById(R.id.NazwiskoEditText);
         LiczbaOcenPoleTekstowe=findViewById(R.id.LiczbaOcenEditText);
         przycisk = (Button)findViewById(R.id.button);
        ImiePoleTekstowe.setOnFocusChangeListener(
                new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        if(ImiePoleTekstowe.getText().toString().isEmpty() && !hasFocus){
                            ImiePoleTekstowe.setError(getString(R.string.ErrorImie));
                            isImie = false;
                            return;
                        };
                        isImie = true;
                        CheckEditText();
                    }
                }
        );
        NazwiskoPoleTekstowe.setOnFocusChangeListener(
                new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        if(NazwiskoPoleTekstowe.getText().toString().isEmpty() && !hasFocus){
                            NazwiskoPoleTekstowe.setError(getString(R.string.ErrorNazwisko));
                            isNazwisko = false;
                            return;
                        };
                        isNazwisko = true;
                        CheckEditText();
                    }
                }
        );
        LiczbaOcenPoleTekstowe.setOnFocusChangeListener(
                new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        if(LiczbaOcenPoleTekstowe.getText().toString().isEmpty()){
                            LiczbaOcenPoleTekstowe.setError(getString(R.string.ErrorLiczbaOcenPuste));
                            isOcena = false;
                            return;
                        }
                        int LiczbaOcen = Integer.parseInt(LiczbaOcenPoleTekstowe.getText().toString());
                        if(!(LiczbaOcen >= 5 && LiczbaOcen  <= 15)){
                            LiczbaOcenPoleTekstowe.setError(getString(R.string.ErrorLiczbaOcenZakres));
                            isNazwisko = false;
                        };
                        isOcena = true;
                        CheckEditText();
                    }
                }
        );
    }
    protected void CheckEditText(){
        if(isImie && isNazwisko && isOcena){
            przycisk.setVisibility(View.VISIBLE);
            return;
        }
        przycisk.setVisibility(View.INVISIBLE);
    }
}